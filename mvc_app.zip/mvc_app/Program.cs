namespace mvc_app
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddDbContext<UsersContext>(); //DB_CONTEXT
            builder.Services.AddScoped<IUserService, UserService>(); //SERVICE
            builder.Services.AddControllersWithViews(); //MVC_WEB
            var app = builder.Build();

            app.UseRouting();

            //http://[ip]:[port]/[controller]/[action]/[id]
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");


            app.Run();
        }
    }
}
